# Hardware Lib

Hardware library contains the implementations of the hardware components that can be connected to the nucleo.
