#ifndef CONFIG_SPRING_H
#define CONFIG_SPRING_H

#ifdef IC2D_SETUP
#define KS 6000
#elif
#define KS 45
#endif

#endif // CONFIG_SPRING_H