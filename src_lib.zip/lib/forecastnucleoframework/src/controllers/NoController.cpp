#include <forecast/controllers/NoController.hpp>

using namespace forecast;
